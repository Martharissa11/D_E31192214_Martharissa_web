<?php 
class Profile extends CI_Controller {
	public function index(){
		$this->load->view('profile');
	}
}
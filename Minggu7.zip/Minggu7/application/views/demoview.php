<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>demo css</title>
    <link rel="stylesheet" href="<?=base_url()?>/public/assets/css/style.css  ?>">
</head>
<body>
    <h2>demo view dengan css</h2>
    <p>contoh demo view dengan css</p>
</body>
</html>
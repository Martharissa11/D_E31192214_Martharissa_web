<p>contoh multiple view dari 1 controller</p>

<!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <?= @$konten; ?>

        </div>
<!-- /.container-fluid -->